<div class="col-md-6 row_4"></div>
	 <div class="col-md-6">
		<div class="row_5">
						<div class="col_1_of_3 span_1_of_3">
							<div class="shop-holder1">
		                        <a href="single.html"><img src="images/pic4.jpg" class="img-responsive" alt=""/></a>
		                    </div>
		                    <div class="shop-content" style="height: 80px;">
		                            <h3><a href="single.html">Non-charac</a></h3>
		                            <span><span class="amount">$45.00</span></span>
		                    </div>
						</div>
						<div class="col_1_of_3 span_1_of_3">
							<div class="shop-holder1">
		                        <a href="single.html"><img src="images/pic5.jpg" class="img-responsive" alt=""/></a>
		                    </div>
		                    <div class="shop-content" style="height: 80px;">
		                            <h3><a href="single.html">Non-charac</a></h3>
		                            <span><span class="amount">$45.00</span></span>
		                    </div>
						</div>
						<div class="col_1_of_3 span_1_of_3">
							<div class="shop-holder1">
		                        <a href="single.html"><img src="images/pic6.jpg" class="img-responsive" alt=""/></a>
		                    </div>
		                    <div class="shop-content" style="height: 80px;">
		                            <h3><a href="single.html">Non-charac</a></h3>
		                            <span><span class="amount">$45.00</span></span>
		                    </div>
						</div>
						<div class="clearfix"></div> 
					</div>
	</div>
	<div class="clearfix"> </div>